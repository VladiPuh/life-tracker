import React from "react";

type Props = {
  title: string;
  children: React.ReactNode;

  bottomNav: React.ReactNode;
  buildLabel?: string | null;
};

export function AppShell({ title, children, bottomNav, buildLabel }: Props) {
  return (
    <div
      style={{
        maxWidth: 520,
        margin: "0 auto",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        fontFamily: "system-ui, Arial",
      }}
    >
      {/* TopBar */}
      <div
        style={{
          flexShrink: 0,
          paddingTop: "var(--safe-top)",
          height: "calc(var(--safe-top) + var(--topbar-h))",
          display: "flex",
          alignItems: "flex-end",
          paddingLeft: "var(--app-pad)",
          paddingRight: "var(--app-pad)",
          paddingBottom: 8,
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 16,
            fontWeight: 800,
            letterSpacing: -0.2,
            color: "var(--lt-text)",
            lineHeight: 1.2,
          }}
        >
          {title}
        </div>
      </div>

      {/* ScrollArea */}
      <div
        style={{
          flex: 1,
          overflowY: "auto",
          paddingLeft: "var(--app-pad)",
          paddingRight: "var(--app-pad)",
          paddingTop: "calc(var(--app-pad) + var(--topbar-gap))",
          paddingBottom: "calc(var(--app-pad) + var(--nav-h) + var(--safe-bottom))",
          WebkitOverflowScrolling: "touch",
        }}
      >
        {children}

        {buildLabel ? (
          <div
            style={{
              marginTop: 22,
              fontSize: 12,
              opacity: 0.35,
              textAlign: "center",
            }}
          >
            build: {buildLabel}
          </div>
        ) : null}
      </div>

      {/* BottomNav (outside scroll) */}
      {bottomNav}
    </div>
  );
}
